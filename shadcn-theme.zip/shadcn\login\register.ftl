<#import "template.ftl" as layout>
<@layout.registrationLayout displayMessage=!messagesPerField.exists('firstName','lastName','email','username','password','password-confirm'); section>
    <#if section = "header">
        <h1 class="auth-title">${msg("registerTitle")}</h1>
        <p class="auth-subtitle">${msg("registerSubtitle")}</p>
    <#elseif section = "form">
        <form id="kc-register-form" action="${url.registrationAction}" method="post">
            <!-- First Name and Last Name in 2 columns -->
            <div class="grid-2">
                <div class="form-group">
                    <label for="firstName" class="form-label">${msg("firstName")}</label>
                    <input type="text" id="firstName" class="form-input <#if messagesPerField.existsError('firstName')>has-error</#if>" name="firstName" value="${(register.formData.firstName!'')}" autocomplete="given-name" />
                    <#if messagesPerField.existsError('firstName')>
                        <span class="field-error-message">
                            ${kcSanitize(messagesPerField.get('firstName'))?no_esc}
                        </span>
                    </#if>
                </div>

                <div class="form-group">
                    <label for="lastName" class="form-label">${msg("lastName")}</label>
                    <input type="text" id="lastName" class="form-input <#if messagesPerField.existsError('lastName')>has-error</#if>" name="lastName" value="${(register.formData.lastName!'')}" autocomplete="family-name" />
                    <#if messagesPerField.existsError('lastName')>
                        <span class="field-error-message">
                            ${kcSanitize(messagesPerField.get('lastName'))?no_esc}
                        </span>
                    </#if>
                </div>
            </div>

            <!-- Email Field -->
            <div class="form-group">
                <label for="email" class="form-label">${msg("email")}</label>
                <input type="email" id="email" class="form-input <#if messagesPerField.existsError('email')>has-error</#if>" name="email" value="${(register.formData.email!'')}" autocomplete="email" placeholder="name@example.com" />
                <#if messagesPerField.existsError('email')>
                    <span class="field-error-message">
                        ${kcSanitize(messagesPerField.get('email'))?no_esc}
                    </span>
                </#if>
            </div>

            <!-- Username Field (if enabled) -->
            <#if !realm.registrationEmailAsUsername>
                <div class="form-group">
                    <label for="username" class="form-label">${msg("username")}</label>
                    <input type="text" id="username" class="form-input <#if messagesPerField.existsError('username')>has-error</#if>" name="username" value="${(register.formData.username!'')}" autocomplete="username" />
                    <#if messagesPerField.existsError('username')>
                        <span class="field-error-message">
                            ${kcSanitize(messagesPerField.get('username'))?no_esc}
                        </span>
                    </#if>
                </div>
            </#if>

            <#if passwordRequired??>
                <!-- Password Field -->
                <div class="form-group">
                    <label for="password" class="form-label">${msg("password")}</label>
                    <div class="input-wrapper">
                        <input type="password" id="password" class="form-input <#if messagesPerField.existsError('password')>has-error</#if>" name="password" autocomplete="new-password" placeholder="••••••••" />
                        <button type="button" class="input-icon-btn toggle-password-btn" data-target="password" aria-label="Toggle password visibility">
                            <svg class="icon-eye" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                            <svg class="icon-eye-off" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: none;"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" y1="2" x2="22" y2="22"/></svg>
                        </button>
                    </div>
                    <div class="password-strength-bar">
                        <div class="strength-segment"></div>
                        <div class="strength-segment"></div>
                        <div class="strength-segment"></div>
                        <div class="strength-segment"></div>
                    </div>
                    <#if messagesPerField.existsError('password')>
                        <span class="field-error-message">
                            ${kcSanitize(messagesPerField.get('password'))?no_esc}
                        </span>
                    </#if>
                </div>

                <!-- Password Confirmation Field -->
                <div class="form-group">
                    <label for="password-confirm" class="form-label">${msg("passwordConfirm")}</label>
                    <div class="input-wrapper">
                        <input type="password" id="password-confirm" class="form-input <#if messagesPerField.existsError('password-confirm')>has-error</#if>" name="password-confirm" autocomplete="new-password" placeholder="••••••••" />
                        <button type="button" class="input-icon-btn toggle-password-btn" data-target="password-confirm" aria-label="Toggle password visibility">
                            <svg class="icon-eye" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                            <svg class="icon-eye-off" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: none;"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" y1="2" x2="22" y2="22"/></svg>
                        </button>
                    </div>
                    <#if messagesPerField.existsError('password-confirm')>
                        <span class="field-error-message">
                            ${kcSanitize(messagesPerField.get('password-confirm'))?no_esc}
                        </span>
                    </#if>
                </div>
            </#if>

            <#if recaptchaRequired??>
                <div class="form-group">
                    <div class="g-recaptcha" data-size="compact" data-sitekey="${recaptchaSiteKey}"></div>
                </div>
            </#if>

            <!-- Terms notice -->
            <p style="font-size: 0.75rem; color: hsl(var(--muted-foreground)); margin-bottom: 1.25rem; line-height: 1.4;">
                ${msg("agreeToTerms")}
            </p>

            <!-- Submit Button -->
            <div class="form-group">
                <button class="btn btn-primary" type="submit">
                    <span>${msg("doRegister")}</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                </button>
            </div>
        </form>

        <div class="auth-footer-nav">
            <span>${msg("alreadyHaveAccount")} <a href="${url.loginUrl}">${msg("signInLink")}</a></span>
        </div>
    </#if>
</@layout.registrationLayout>
