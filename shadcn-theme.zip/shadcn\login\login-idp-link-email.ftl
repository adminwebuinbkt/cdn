<#import "template.ftl" as layout>
<@layout.registrationLayout; section>
    <#if section = "header">
        <div style="width: 48px; height: 48px; border-radius: 50%; background-color: hsl(var(--primary)/0.1); color: hsl(var(--primary)); display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
        </div>
        <h1 class="auth-title">${msg("emailLinkIdpTitle", idpAlias!"Identity Provider")}</h1>
        <p class="auth-subtitle">${msg("emailLinkIdpSubtitle")}</p>
    <#elseif section = "form">
        <p style="font-size: 0.875rem; text-align: center; color: hsl(var(--muted-foreground)); margin: 1.5rem 0; line-height: 1.5;">
            ${msg("emailLinkIdp1", idpAlias!"Identity Provider", brokerContext.username!'', realm.displayName!(realm.name!'Keycloak'))}
        </p>

        <div class="form-group">
            <a href="${url.loginAction}" class="btn btn-primary" style="width: 100%;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
                <span>${msg("doClickHere")} ${msg("emailLinkIdp2")}</span>
            </a>
        </div>
    </#if>
</@layout.registrationLayout>
