<#import "template.ftl" as layout>
<@layout.mainLayout active='federatedIdentity' bodyClass='federatedIdentity'>

    <div class="page-header">
        <h1 class="page-title">${msg("federatedIdentityTitle")}</h1>
        <p class="page-subtitle">${msg("federatedIdentitySubtitle")}</p>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">${msg("federatedIdentityTitle")}</h2>
            <p class="card-description">Connect external accounts to sign in with single click.</p>
        </div>

        <div class="card-content" style="padding: 0;">
            <div class="table-wrapper">
                <table class="shadcn-table">
                    <thead>
                        <tr>
                            <th>Provider</th>
                            <th>Account Identifier</th>
                            <th>Status</th>
                            <th style="text-align: right;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <#list federatedIdentity.identities as identity>
                            <tr>
                                <td style="font-weight: 500;">
                                    ${identity.displayName!}
                                </td>
                                <td style="color: hsl(var(--muted-foreground));">
                                    <#if identity.connected>
                                        ${identity.userName!}
                                    <#else>
                                        &mdash;
                                    </#if>
                                </td>
                                <td>
                                    <#if identity.connected>
                                        <span class="badge badge-success">${msg("connected")}</span>
                                    <#else>
                                        <span class="badge badge-secondary">${msg("notConnected")}</span>
                                    </#if>
                                </td>
                                <td style="text-align: right;">
                                    <#if identity.connected>
                                        <#if federatedIdentity.removeLinkPossible>
                                            <form action="${url.getLogoutUrl(identity.providerId)}" method="post" style="display: inline;">
                                                <input type="hidden" id="stateChecker" name="stateChecker" value="${stateChecker}">
                                                <button class="btn btn-outline" style="height: 2rem; padding: 0 0.75rem; font-size: 0.75rem; color: hsl(var(--destructive));">
                                                    ${msg("disconnect")}
                                                </button>
                                            </form>
                                        </#if>
                                    <#else>
                                        <a href="${url.getLoginUrl(identity.providerId)}" class="btn btn-outline" style="height: 2rem; padding: 0 0.75rem; font-size: 0.75rem;">
                                            ${msg("connect")}
                                        </a>
                                    </#if>
                                </td>
                            </tr>
                        </#list>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</@layout.mainLayout>
