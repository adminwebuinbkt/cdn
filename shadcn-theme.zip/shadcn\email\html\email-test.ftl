<#import "template.ftl" as layout>
<@layout.emailLayout>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td style="padding-bottom: 16px;">
                <h1 style="margin: 0; font-size: 20px; font-weight: 600; color: #09090b; letter-spacing: -0.025em;">
                    ${msg("emailTestSubject")}
                </h1>
            </td>
        </tr>
        <tr>
            <td style="padding-bottom: 24px; font-size: 14px; line-height: 1.6; color: #52525b;">
                <p style="margin: 0 0 12px 0;">${msg("emailTestBody")}</p>
                <div style="background-color: #f4f4f5; border-radius: 6px; padding: 12px 16px; font-family: monospace; font-size: 13px; color: #18181b;">
                    SMTP Status: Successfully connected & delivered!
                </div>
            </td>
        </tr>
        <tr>
            <td style="padding-top: 16px; border-top: 1px solid #e4e4e7; font-size: 12px; line-height: 1.5; color: #71717a;">
                <p style="margin: 0;">Sent by ${properties.logoText!(realmName!'Keycloak')} Realm Administrator.</p>
            </td>
        </tr>
    </table>
</@layout.emailLayout>
