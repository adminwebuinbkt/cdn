${msg("passwordResetSubject")}

${msg("passwordResetBody")}

${link}

${msg("linkExpirationNotice", linkExpiration)}
