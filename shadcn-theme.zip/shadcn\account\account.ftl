<#import "template.ftl" as layout>
<@layout.mainLayout active='account' bodyClass='account'>

    <div class="page-header">
        <h1 class="page-title">${msg("accountDetailsTitle")}</h1>
        <p class="page-subtitle">${msg("accountDetailsSubtitle")}</p>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">${msg("accountDetailsTitle")}</h2>
            <p class="card-description">Update your photo and personal details here.</p>
        </div>

        <form action="${url.accountUrl}" method="post">
            <input type="hidden" id="stateChecker" name="stateChecker" value="${stateChecker}">

            <div class="card-content">
                <div class="form-grid">
                    <!-- Username -->
                    <div class="form-group">
                        <label for="username" class="form-label">${msg("username")}</label>
                        <input type="text" id="username" name="username" class="form-input" <#if !realm.editUsernameAllowed>disabled="disabled"</#if> value="${(account.username!'')}"/>
                    </div>

                    <!-- Email -->
                    <div class="form-group">
                        <label for="email" class="form-label">${msg("email")}</label>
                        <input type="email" id="email" name="email" class="form-input" <#if !realm.registrationEmailAsUsername && realm.editUsernameAllowed>autofocus</#if> value="${(account.email!'')}"/>
                    </div>

                    <!-- First Name -->
                    <div class="form-group">
                        <label for="firstName" class="form-label">${msg("firstName")}</label>
                        <input type="text" id="firstName" name="firstName" class="form-input" value="${(account.firstName!'')}"/>
                    </div>

                    <!-- Last Name -->
                    <div class="form-group">
                        <label for="lastName" class="form-label">${msg("lastName")}</label>
                        <input type="text" id="lastName" name="lastName" class="form-input" value="${(account.lastName!'')}"/>
                    </div>
                </div>
            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary" name="submitAction" value="Save">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                    <span>${msg("saveChanges")}</span>
                </button>
            </div>
        </form>
    </div>

</@layout.mainLayout>
