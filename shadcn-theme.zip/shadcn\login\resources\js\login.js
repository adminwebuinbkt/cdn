/**
 * Shadcn UI Theme for Keycloak - Login Scripts
 */

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initPasswordToggles();
  initOtpInputs();
  initPasswordStrength();
});

/**
 * Dark / Light Mode System
 */
function initTheme() {
  const savedTheme = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
    document.documentElement.classList.add('dark');
  } else {
    document.documentElement.classList.remove('dark');
  }

  const toggleBtn = document.getElementById('theme-toggle-btn');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      const isDark = document.documentElement.classList.toggle('dark');
      localStorage.setItem('theme', isDark ? 'dark' : 'light');
      updateToggleIcons(isDark);
    });
    updateToggleIcons(document.documentElement.classList.contains('dark'));
  }
}

function updateToggleIcons(isDark) {
  const sunIcon = document.getElementById('theme-icon-sun');
  const moonIcon = document.getElementById('theme-icon-moon');
  if (sunIcon && moonIcon) {
    if (isDark) {
      sunIcon.style.display = 'block';
      moonIcon.style.display = 'none';
    } else {
      sunIcon.style.display = 'none';
      moonIcon.style.display = 'block';
    }
  }
}

/**
 * Toggle Password Visibility
 */
function initPasswordToggles() {
  const toggleButtons = document.querySelectorAll('.toggle-password-btn');
  toggleButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const input = document.getElementById(targetId);
      if (!input) return;

      const isPassword = input.getAttribute('type') === 'password';
      input.setAttribute('type', isPassword ? 'text' : 'password');

      const eyeIcon = btn.querySelector('.icon-eye');
      const eyeOffIcon = btn.querySelector('.icon-eye-off');
      if (eyeIcon && eyeOffIcon) {
        eyeIcon.style.display = isPassword ? 'none' : 'block';
        eyeOffIcon.style.display = isPassword ? 'block' : 'none';
      }
    });
  });
}

/**
 * Auto-focus & handle multi-digit OTP inputs
 */
function initOtpInputs() {
  const otpContainer = document.querySelector('.otp-inputs');
  if (!otpContainer) return;

  const boxes = otpContainer.querySelectorAll('.otp-box');
  const hiddenOtpInput = document.getElementById('otp');

  boxes.forEach((box, index) => {
    box.addEventListener('input', (e) => {
      const val = e.target.value;
      if (val.length >= 1) {
        box.value = val[val.length - 1]; // Only take last character
        if (index < boxes.length - 1) {
          boxes[index + 1].focus();
        }
      }
      syncHiddenOtp();
    });

    box.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !box.value && index > 0) {
        boxes[index - 1].focus();
      }
    });

    box.addEventListener('paste', (e) => {
      e.preventDefault();
      const pasted = (e.clipboardData || window.clipboardData).getData('text').trim();
      if (/^\d+$/.test(pasted)) {
        pasted.split('').slice(0, boxes.length).forEach((char, i) => {
          boxes[i].value = char;
        });
        syncHiddenOtp();
        if (pasted.length < boxes.length) {
          boxes[pasted.length].focus();
        } else {
          boxes[boxes.length - 1].focus();
        }
      }
    });
  });

  function syncHiddenOtp() {
    if (!hiddenOtpInput) return;
    let code = '';
    boxes.forEach(b => code += b.value);
    hiddenOtpInput.value = code;
  }
}

/**
 * Real-time Password Strength Meter
 */
function initPasswordStrength() {
  const passwordInput = document.getElementById('password-new') || document.getElementById('password');
  const segments = document.querySelectorAll('.strength-segment');
  if (!passwordInput || segments.length === 0) return;

  passwordInput.addEventListener('input', () => {
    const val = passwordInput.value;
    let score = 0;
    if (val.length >= 8) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;

    segments.forEach((seg, i) => {
      seg.className = 'strength-segment';
      if (i < score) {
        if (score === 1) seg.classList.add('active-weak');
        else if (score === 2) seg.classList.add('active-fair');
        else if (score === 3) seg.classList.add('active-good');
        else if (score >= 4) seg.classList.add('active-strong');
      }
    });
  });
}
