<#import "template.ftl" as layout>
<@layout.registrationLayout displayMessage=false; section>
    <#if section = "header">
        <div style="width: 48px; height: 48px; border-radius: 50%; background-color: hsl(var(--info)/0.15); color: hsl(var(--info)); display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
        </div>
        <h1 class="auth-title"><#if messageHeader??>${messageHeader}<#else>${message.summary}</#if></h1>
    <#elseif section = "form">
        <p style="font-size: 0.9375rem; text-align: center; color: hsl(var(--muted-foreground)); line-height: 1.6; margin: 1.5rem 0;">
            ${message.summary}
            <#if (message.type = 'success' && pageRedirectUri??)>
                <script>setTimeout(function() { window.location.href = '${pageRedirectUri}'; }, 2000);</script>
            </#if>
        </p>

        <#if actionUri??>
            <div class="form-group">
                <a href="${actionUri}" class="btn btn-primary" style="width: 100%;">${msg("proceedWithAction")}</a>
            </div>
        <#elseif (client.baseUrl)??>
            <div class="form-group">
                <a href="${client.baseUrl}" class="btn btn-primary" style="width: 100%;">${kcSanitize(msg("backToApplication"))?no_esc}</a>
            </div>
        <#elseif pageRedirectUri??>
            <div class="form-group">
                <a href="${pageRedirectUri}" class="btn btn-primary" style="width: 100%;">${kcSanitize(msg("backToApplication"))?no_esc}</a>
            </div>
        </#if>
    </#if>
</@layout.registrationLayout>
