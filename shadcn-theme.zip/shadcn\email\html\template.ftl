<#macro emailLayout>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>${realmName!'Keycloak'}</title>
    <style type="text/css">
        body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
        table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
        img { -ms-interpolation-mode: bicubic; border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none; }
        table { border-collapse: collapse !important; }
        body { height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f4f4f5; color: #18181b; }
        @media screen and (max-width: 600px) {
            .email-container { width: 100% !important; padding: 12px !important; }
            .content-card { padding: 24px 16px !important; }
        }
    </style>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f5;">
    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed; background-color: #f4f4f5;">
        <tr>
            <td align="center" style="padding: 40px 10px;">
                <!-- Container Card -->
                <table class="email-container" border="0" cellpadding="0" cellspacing="0" width="560" style="max-width: 560px; width: 100%;">
                    <!-- Header Logo -->
                    <tr>
                        <td align="center" style="padding-bottom: 24px;">
                            <table border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td align="center" style="font-size: 18px; font-weight: 700; color: #09090b; letter-spacing: -0.025em;">
                                        ${properties.logoText!(realmName!'Keycloak')}
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>

                    <!-- Main Card -->
                    <tr>
                        <td class="content-card" style="background-color: #ffffff; border: 1px solid #e4e4e7; border-radius: 8px; padding: 36px 32px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                            <#nested>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td align="center" style="padding-top: 24px; font-size: 12px; color: #71717a; line-height: 1.5;">
                            <p style="margin: 0 0 8px 0;">${properties.logoText!(realmName!'Keycloak')} &bull; ${msg("emailFooterCopyright")}</p>
                            <p style="margin: 0;">If you have any questions, please reach out to <a href="mailto:${properties.supportEmail!'support@example.com'}" style="color: #09090b; text-decoration: underline;">${properties.supportEmail!'support@example.com'}</a></p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
</#macro>
