<#import "template.ftl" as layout>
<@layout.emailLayout>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td style="padding-bottom: 16px;">
                <h1 style="margin: 0; font-size: 20px; font-weight: 600; color: #09090b; letter-spacing: -0.025em;">
                    ${msg("executeActionsSubject")}
                </h1>
            </td>
        </tr>
        <tr>
            <td style="padding-bottom: 24px; font-size: 14px; line-height: 1.6; color: #52525b;">
                <p style="margin: 0;">${msg("executeActionsBody")}</p>
            </td>
        </tr>
        <!-- CTA Button -->
        <tr>
            <td align="center" style="padding-bottom: 24px;">
                <table border="0" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="center" style="border-radius: 6px; background-color: #09090b;">
                            <a href="${link}" target="_blank" style="display: inline-block; padding: 12px 24px; font-size: 14px; font-weight: 500; color: #ffffff; text-decoration: none; border-radius: 6px; background-color: #09090b;">
                                ${msg("executeActionsBtn")}
                            </a>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <!-- Notice -->
        <tr>
            <td style="padding-top: 16px; border-top: 1px solid #e4e4e7; font-size: 12px; line-height: 1.5; color: #71717a;">
                <p style="margin: 0 0 8px 0;">${msg("linkExpirationNotice", linkExpiration)}</p>
                <p style="margin: 0; word-break: break-all;">Direct link: <a href="${link}" style="color: #09090b; text-decoration: underline;">${link}</a></p>
            </td>
        </tr>
    </table>
</@layout.emailLayout>
