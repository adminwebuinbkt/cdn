<#import "template.ftl" as layout>
<@layout.registrationLayout displayMessage=!messagesPerField.exists('totp'); section>
    <#if section = "header">
        <h1 class="auth-title">${msg("otpTitle")}</h1>
        <p class="auth-subtitle">${msg("otpSubtitle")}</p>
    <#elseif section = "form">
        <form id="kc-otp-login-form" action="${url.loginAction}" method="post">
            <#if otpLogin.userOtpCredentials?size gt 1>
                <div class="form-group">
                    <label class="form-label">${msg("loginOtpCredential")}</label>
                    <select name="selectedCredentialId" class="form-input">
                        <#list otpLogin.userOtpCredentials as credential>
                            <option value="${credential.id}">${credential.userLabel}</option>
                        </#list>
                    </select>
                </div>
            </#if>

            <div class="form-group">
                <label for="otp" class="form-label">${msg("loginOtpOneTime")}</label>
                <!-- Digit boxes UI -->
                <div class="otp-inputs">
                    <input type="text" maxlength="1" class="otp-box" autofocus inputmode="numeric" pattern="[0-9]*" />
                    <input type="text" maxlength="1" class="otp-box" inputmode="numeric" pattern="[0-9]*" />
                    <input type="text" maxlength="1" class="otp-box" inputmode="numeric" pattern="[0-9]*" />
                    <input type="text" maxlength="1" class="otp-box" inputmode="numeric" pattern="[0-9]*" />
                    <input type="text" maxlength="1" class="otp-box" inputmode="numeric" pattern="[0-9]*" />
                    <input type="text" maxlength="1" class="otp-box" inputmode="numeric" pattern="[0-9]*" />
                </div>
                <!-- Actual hidden OTP input for Keycloak form submission -->
                <input id="otp" name="otp" type="hidden" autocomplete="off" />

                <#if messagesPerField.existsError('totp')>
                    <span class="field-error-message">
                        ${kcSanitize(messagesPerField.get('totp'))?no_esc}
                    </span>
                </#if>
            </div>

            <div class="form-group" style="margin-top: 1.5rem;">
                <button class="btn btn-primary" name="login" id="kc-login" type="submit">
                    <span>${msg("doLogIn")}</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                </button>
            </div>
        </form>
    </#if>
</@layout.registrationLayout>
