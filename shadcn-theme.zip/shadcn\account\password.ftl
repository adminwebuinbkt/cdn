<#import "template.ftl" as layout>
<@layout.mainLayout active='password' bodyClass='password'>

    <div class="page-header">
        <h1 class="page-title">${msg("passwordTitle")}</h1>
        <p class="page-subtitle">${msg("passwordSubtitle")}</p>
    </div>

    <div class="card">
        <div class="card-header">
            <h2 class="card-title">${msg("passwordTitle")}</h2>
            <p class="card-description">Please enter your current password to change your password.</p>
        </div>

        <form action="${url.passwordUrl}" method="post">
            <input type="hidden" id="stateChecker" name="stateChecker" value="${stateChecker}">

            <div class="card-content" style="max-width: 480px;">
                <#if password.passwordSet>
                    <div class="form-group">
                        <label for="password" class="form-label">${msg("currentPassword")}</label>
                        <input type="password" id="password" name="password" class="form-input" autofocus autocomplete="current-password" placeholder="••••••••"/>
                    </div>
                </#if>

                <div class="form-group">
                    <label for="password-new" class="form-label">${msg("newPassword")}</label>
                    <input type="password" id="password-new" name="password-new" class="form-input" autocomplete="new-password" placeholder="••••••••"/>
                </div>

                <div class="form-group">
                    <label for="password-confirm" class="form-label">${msg("confirmPassword")}</label>
                    <input type="password" id="password-confirm" name="password-confirm" class="form-input" autocomplete="new-password" placeholder="••••••••"/>
                </div>
            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary" name="submitAction" value="Save">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                    <span>${msg("saveChanges")}</span>
                </button>
            </div>
        </form>
    </div>

</@layout.mainLayout>
