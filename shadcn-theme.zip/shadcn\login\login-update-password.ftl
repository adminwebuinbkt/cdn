<#import "template.ftl" as layout>
<@layout.registrationLayout displayMessage=!messagesPerField.exists('password','password-confirm'); section>
    <#if section = "header">
        <h1 class="auth-title">${msg("updatePasswordTitle")}</h1>
        <p class="auth-subtitle">${msg("updatePasswordSubtitle")}</p>
    <#elseif section = "form">
        <form id="kc-passwd-update-form" action="${url.loginAction}" method="post">
            <input type="text" id="username" name="username" value="${username}" autocomplete="username" readonly="readonly" style="display:none;"/>
            <input type="password" id="password" name="password" autocomplete="current-password" style="display:none;"/>

            <div class="form-group">
                <label for="password-new" class="form-label">${msg("passwordNew")}</label>
                <div class="input-wrapper">
                    <input type="password" id="password-new" name="password-new" class="form-input <#if messagesPerField.existsError('password','password-confirm')>has-error</#if>" autofocus autocomplete="new-password" placeholder="••••••••" />
                    <button type="button" class="input-icon-btn toggle-password-btn" data-target="password-new" aria-label="Toggle password visibility">
                        <svg class="icon-eye" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                        <svg class="icon-eye-off" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: none;"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" y1="2" x2="22" y2="22"/></svg>
                    </button>
                </div>
                <div class="password-strength-bar">
                    <div class="strength-segment"></div>
                    <div class="strength-segment"></div>
                    <div class="strength-segment"></div>
                    <div class="strength-segment"></div>
                </div>
                <#if messagesPerField.existsError('password')>
                    <span class="field-error-message">
                        ${kcSanitize(messagesPerField.get('password'))?no_esc}
                    </span>
                </#if>
            </div>

            <div class="form-group">
                <label for="password-confirm" class="form-label">${msg("passwordConfirm")}</label>
                <div class="input-wrapper">
                    <input type="password" id="password-confirm" name="password-confirm" class="form-input <#if messagesPerField.existsError('password-confirm')>has-error</#if>" autocomplete="new-password" placeholder="••••••••" />
                    <button type="button" class="input-icon-btn toggle-password-btn" data-target="password-confirm" aria-label="Toggle password visibility">
                        <svg class="icon-eye" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                        <svg class="icon-eye-off" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: none;"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" y1="2" x2="22" y2="22"/></svg>
                    </button>
                </div>
                <#if messagesPerField.existsError('password-confirm')>
                    <span class="field-error-message">
                        ${kcSanitize(messagesPerField.get('password-confirm'))?no_esc}
                    </span>
                </#if>
            </div>

            <div class="form-group" style="margin-top: 1.5rem;">
                <#if isAppInitiatedAction??>
                    <button class="btn btn-primary" type="submit" name="submitAction" value="Update">${msg("doSubmit")}</button>
                    <button class="btn btn-outline" style="margin-top: 0.5rem;" type="submit" name="cancel-aio" value="true">${msg("doCancel")}</button>
                <#else>
                    <button class="btn btn-primary" type="submit">${msg("doSubmit")}</button>
                </#if>
            </div>
        </form>
    </#if>
</@layout.registrationLayout>
