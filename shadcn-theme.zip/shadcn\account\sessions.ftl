<#import "template.ftl" as layout>
<@layout.mainLayout active='sessions' bodyClass='sessions'>

    <div class="page-header">
        <h1 class="page-title">${msg("sessionsTitle")}</h1>
        <p class="page-subtitle">${msg("sessionsSubtitle")}</p>
    </div>

    <div class="card">
        <div class="card-header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem;">
            <div>
                <h2 class="card-title">${msg("sessionsTitle")}</h2>
                <p class="card-description">Devices currently authenticated to your realm account.</p>
            </div>

            <form action="${url.sessionsUrl}" method="post">
                <input type="hidden" id="stateChecker" name="stateChecker" value="${stateChecker}">
                <button id="logout-all-sessions" class="btn btn-outline" type="submit" name="submitAction" value="logsout">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>
                    <span>${msg("logOutAllSessions")}</span>
                </button>
            </form>
        </div>

        <div class="card-content" style="padding: 0;">
            <div class="table-wrapper">
                <table class="shadcn-table">
                    <thead>
                        <tr>
                            <th>${msg("ipAddress")}</th>
                            <th>${msg("started")}</th>
                            <th>${msg("lastAccess")}</th>
                            <th>${msg("browser")}</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <#list sessions.sessions as session>
                            <tr>
                                <td style="font-weight: 500; font-family: monospace;">${session.ipAddress}</td>
                                <td style="color: hsl(var(--muted-foreground));">${session.started?datetime}</td>
                                <td style="color: hsl(var(--muted-foreground));">${session.lastAccess?datetime}</td>
                                <td>
                                    <#list session.clients as client>
                                        <span class="badge badge-secondary" style="margin-right: 0.25rem;">${client}</span>
                                    </#list>
                                </td>
                                <td>
                                    <#if session.id == sessions.id>
                                        <span class="badge badge-success">${msg("currentSession")}</span>
                                    <#else>
                                        <span class="badge badge-secondary">Active</span>
                                    </#if>
                                </td>
                            </tr>
                        </#list>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</@layout.mainLayout>
