<#macro registrationLayout displayInfo=false displayMessage=true displayRequiredFields=false showAnotherWayIfPresent=true>
<!DOCTYPE html>
<html lang="${locale.currentLanguageTag!'en'}" class="">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>${msg("loginTitle", (realm.displayName!'Keycloak'))}</title>
    <link rel="icon" href="${url.resourcesPath}/img/favicon.ico" />

    <#if properties.styles?has_content>
        <#list properties.styles?split(' ') as style>
            <link href="${url.resourcesPath}/${style}" rel="stylesheet" />
        </#list>
    </#if>

    <#if properties.scripts?has_content>
        <#list properties.scripts?split(' ') as script>
            <script src="${url.resourcesPath}/${script}" type="text/javascript"></script>
        </#list>
    </#if>
</head>

<body>
    <div class="auth-container">
        <!-- Left Hero Section (Desktop Only) -->
        <div class="auth-banner">
            <div class="banner-logo">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                </svg>
                <span>${properties.logoText!(realm.displayNameHtml!'Keycloak')}</span>
            </div>

            <div class="banner-quote">
                <p>"Next-generation authentication and identity management built with enterprise security and modern design aesthetics."</p>
                <footer>Designed with shadcn/ui & Tailwind CSS</footer>
            </div>

            <div class="banner-footer">
                &copy; ${(realm.name)!} Identity Management. All rights reserved.
            </div>
        </div>

        <!-- Right / Centered Auth Form Section -->
        <div class="auth-main">
            <!-- Topbar (Mobile Logo + Theme Switcher + Locale Selector) -->
            <div class="auth-topbar">
                <div class="mobile-logo">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                    </svg>
                    <span>${properties.logoText!(realm.displayNameHtml!'Keycloak')}</span>
                </div>

                <div class="topbar-actions">
                    <!-- Language Selector -->
                    <#if realm.internationalizationEnabled?? && realm.internationalizationEnabled && locale.supported?size gt 1>
                        <div class="locale-dropdown-wrapper">
                            <select class="locale-select" onchange="window.location.href=this.value">
                                <#list locale.supported as l>
                                    <option value="${l.url}" <#if l.label == locale.current>selected</#if>>${l.label}</option>
                                </#list>
                            </select>
                            <svg class="locale-select-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="m6 9 6 6 6-6"/>
                            </svg>
                        </div>
                    </#if>

                    <!-- Dark/Light Theme Toggle -->
                    <button id="theme-toggle-btn" class="btn-icon" aria-label="Toggle theme" title="Toggle theme">
                        <!-- Sun Icon (shown in dark mode) -->
                        <svg id="theme-icon-sun" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: none;">
                            <circle cx="12" cy="12" r="4"/>
                            <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>
                        </svg>
                        <!-- Moon Icon (shown in light mode) -->
                        <svg id="theme-icon-moon" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>
                        </svg>
                    </button>
                </div>
            </div>

            <!-- Form Card Wrapper -->
            <div class="auth-card-wrapper">
                <div class="auth-card">
                    <!-- Header -->
                    <div class="auth-header">
                        <#nested "header">
                    </div>

                    <!-- Alerts / Feedback Messages -->
                    <#if displayMessage && message?has_content && (message.type != 'warning' || !isAppInitiatedAction??)>
                        <div class="alert alert-${message.type}">
                            <#if message.type = 'success'>
                                <svg class="alert-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                                    <path d="m9 11 3 3L22 4"/>
                                </svg>
                            <#elseif message.type = 'warning'>
                                <svg class="alert-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/>
                                    <line x1="12" y1="9" x2="12" y2="13"/>
                                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                                </svg>
                            <#elseif message.type = 'error'>
                                <svg class="alert-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="12" r="10"/>
                                    <line x1="15" y1="9" x2="9" y2="15"/>
                                    <line x1="9" y1="9" x2="15" y2="15"/>
                                </svg>
                            <#else>
                                <svg class="alert-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="12" r="10"/>
                                    <line x1="12" y1="16" x2="12" y2="12"/>
                                    <line x1="12" y1="8" x2="12.01" y2="8"/>
                                </svg>
                            </#if>
                            <span>${kcSanitize(message.summary)?no_esc}</span>
                        </div>
                    </#if>

                    <!-- Form Content -->
                    <#nested "form">

                    <!-- Social / Identity Providers -->
                    <#nested "socialProviders">

                    <!-- Additional Info / Footer link -->
                    <#if displayInfo>
                        <div class="auth-footer-nav">
                            <#nested "info">
                        </div>
                    </#if>
                </div>
            </div>

            <!-- Bottom Legal Links -->
            <div class="auth-bottom-links">
                <a href="${properties.termsUrl!'#'}">Terms of Service</a>
                &bull;
                <a href="${properties.privacyUrl!'#'}">Privacy Policy</a>
                &bull;
                <a href="${properties.supportUrl!'#'}">Support</a>
            </div>
        </div>
    </div>
</body>
</html>
</#macro>
