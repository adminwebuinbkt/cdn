<#macro mainLayout active bodyClass>
<!DOCTYPE html>
<html lang="${locale.currentLanguageTag!'en'}" class="">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>${msg("accountConsoleTitle")} - ${(realm.displayNameHtml!'Keycloak')}</title>
    <link rel="icon" href="${url.resourcesPath}/img/favicon.ico" />

    <#if properties.styles?has_content>
        <#list properties.styles?split(' ') as style>
            <link href="${url.resourcesPath}/${style}" rel="stylesheet" />
        </#list>
    </#if>

    <#if properties.scripts?has_content>
        <#list properties.scripts?split(' ') as script>
            <script src="${url.resourcesPath}/${script}" type="text/javascript"></script>
        </#list>
    </#if>
</head>

<body>
    <div class="dashboard-layout">
        <!-- Sidebar Navigation -->
        <aside class="dashboard-sidebar">
            <div class="sidebar-header">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                </svg>
                <span>${properties.logoText!(realm.displayNameHtml!'Keycloak')}</span>
            </div>

            <nav class="sidebar-nav">
                <!-- Personal Info -->
                <a href="${url.accountUrl}" class="nav-item <#if active=='account'>active</#if>">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    <span>${msg("profileTab")}</span>
                </a>

                <!-- Password -->
                <#if realm.password>
                    <a href="${url.passwordUrl}" class="nav-item <#if active=='password'>active</#if>">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                        <span>${msg("passwordTab")}</span>
                    </a>
                </#if>

                <!-- Authenticator 2FA -->
                <a href="${url.totpUrl}" class="nav-item <#if active=='totp'>active</#if>">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    <span>${msg("totpTab")}</span>
                </a>

                <!-- Sessions -->
                <#if realm.isUserManagedAccessAllowed()?? || true>
                    <a href="${url.sessionsUrl}" class="nav-item <#if active=='sessions'>active</#if>">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="14" x="2" y="3" rx="2"/><line x1="8" x2="16" y1="21" y2="21"/><line x1="12" x2="12" y1="17" y2="21"/></svg>
                        <span>${msg("sessionsTab")}</span>
                    </a>
                </#if>

                <!-- Federated Identity -->
                <#if realm.identityFederationEnabled>
                    <a href="${url.federatedIdentityUrl}" class="nav-item <#if active=='federatedIdentity'>active</#if>">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/></svg>
                        <span>${msg("federatedIdentityTab")}</span>
                    </a>
                </#if>
            </nav>

            <div class="sidebar-footer">
                <a href="${url.logoutUrl}" class="btn btn-outline" style="width: 100%; justify-content: flex-start;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>
                    <span>${msg("signOut")}</span>
                </a>
            </div>
        </aside>

        <!-- Main Dashboard Wrapper -->
        <div class="dashboard-main">
            <!-- Topbar Header -->
            <header class="dashboard-topbar">
                <div class="topbar-left">
                    <button id="mobile-menu-toggle" class="mobile-menu-btn" aria-label="Toggle menu">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
                    </button>
                    <span class="breadcrumb-text">Settings / <#if active=='account'>Personal Info<#elseif active=='password'>Password<#elseif active=='totp'>Authenticator<#elseif active=='sessions'>Sessions<#elseif active=='federatedIdentity'>Connected Accounts<#else>Account</#if></span>
                </div>

                <div class="topbar-right">
                    <!-- Theme Toggle -->
                    <button id="theme-toggle-btn" class="btn-icon" aria-label="Toggle theme">
                        <svg id="theme-icon-sun" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: none;"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>
                        <svg id="theme-icon-moon" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>
                    </button>

                    <!-- User Pill -->
                    <div class="user-badge">
                        <div class="user-avatar">
                            ${(account.firstName!'U')?substring(0, 1)?upper_case}
                        </div>
                        <span style="font-size: 0.875rem; font-weight: 500;">${(account.username!(account.email!'User'))}</span>
                    </div>
                </div>
            </header>

            <!-- Dashboard Content Body -->
            <main class="dashboard-body">
                <!-- Flash Feedback Message -->
                <#if message?has_content>
                    <div class="alert alert-${message.type}">
                        <#if message.type = 'success'>
                            <svg class="alert-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/></svg>
                        <#else>
                            <svg class="alert-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                        </#if>
                        <span>${kcSanitize(message.summary)?no_esc}</span>
                    </div>
                </#if>

                <#nested>
            </main>
        </div>
    </div>
</body>
</html>
</#macro>
