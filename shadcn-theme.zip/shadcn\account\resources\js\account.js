/**
 * Shadcn UI Theme for Keycloak - Account Console Scripts
 */

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initMobileSidebar();
  initCopyKey();
});

function initTheme() {
  const savedTheme = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
    document.documentElement.classList.add('dark');
  } else {
    document.documentElement.classList.remove('dark');
  }

  const toggleBtn = document.getElementById('theme-toggle-btn');
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      const isDark = document.documentElement.classList.toggle('dark');
      localStorage.setItem('theme', isDark ? 'dark' : 'light');
      updateIcons(isDark);
    });
    updateIcons(document.documentElement.classList.contains('dark'));
  }
}

function updateIcons(isDark) {
  const sunIcon = document.getElementById('theme-icon-sun');
  const moonIcon = document.getElementById('theme-icon-moon');
  if (sunIcon && moonIcon) {
    sunIcon.style.display = isDark ? 'block' : 'none';
    moonIcon.style.display = isDark ? 'none' : 'block';
  }
}

function initMobileSidebar() {
  const menuBtn = document.getElementById('mobile-menu-toggle');
  const sidebar = document.querySelector('.dashboard-sidebar');
  if (menuBtn && sidebar) {
    menuBtn.addEventListener('click', () => {
      sidebar.classList.toggle('sidebar-open');
    });

    // Close when clicking outside on mobile
    document.addEventListener('click', (e) => {
      if (sidebar.classList.contains('sidebar-open') && !sidebar.contains(e.target) && !menuBtn.contains(e.target)) {
        sidebar.classList.remove('sidebar-open');
      }
    });
  }
}

function initCopyKey() {
  const copyBtn = document.getElementById('copy-totp-key-btn');
  const keyText = document.getElementById('totp-secret-key');
  if (copyBtn && keyText) {
    copyBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(keyText.innerText.trim()).then(() => {
        const origText = copyBtn.innerText;
        copyBtn.innerText = 'Copied!';
        setTimeout(() => { copyBtn.innerText = origText; }, 2000);
      });
    });
  }
}
