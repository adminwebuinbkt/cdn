<#import "template.ftl" as layout>
<@layout.mainLayout active='totp' bodyClass='totp'>

    <div class="page-header">
        <h1 class="page-title">${msg("totpTitle")}</h1>
        <p class="page-subtitle">${msg("totpSubtitle")}</p>
    </div>

    <#if totp.enabled>
        <div class="card">
            <div class="card-header">
                <div style="display: flex; align-items: center; justify-content: space-between;">
                    <div>
                        <h2 class="card-title">${msg("totpTitle")}</h2>
                        <p class="card-description">Two-Factor Authentication is currently enabled on your account.</p>
                    </div>
                    <span class="badge badge-success">Enabled</span>
                </div>
            </div>

            <div class="card-content">
                <p style="font-size: 0.875rem; color: hsl(var(--muted-foreground));">
                    Your account is protected by an Authenticator App (TOTP). You can remove or reconfigure your authenticator at any time.
                </p>
            </div>

            <#if mode?? && mode = "manual">
            <#else>
                <div class="card-footer">
                    <form action="${url.totpUrl}" method="post">
                        <input type="hidden" id="stateChecker" name="stateChecker" value="${stateChecker}">
                        <input type="hidden" name="submitAction" value="Delete">
                        <button type="submit" class="btn btn-destructive">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                            <span>Disable Two-Factor Authentication</span>
                        </button>
                    </form>
                </div>
            </#if>
        </div>
    <#else>
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Setup Authenticator App</h2>
                <p class="card-description">${msg("scanQrInstruction")}</p>
            </div>

            <form action="${url.totpUrl}" method="post">
                <input type="hidden" id="stateChecker" name="stateChecker" value="${stateChecker}">

                <div class="card-content">
                    <div class="qr-container">
                        <!-- QR Code Image -->
                        <div class="qr-image-box">
                            <img id="kc-totp-secret-qr-code" src="data:image/png;base64, ${totp.totpSecretQrCode}" alt="TOTP QR Code" style="width: 160px; height: 160px; display: block;" />
                        </div>

                        <div style="flex: 1; min-width: 260px;">
                            <label class="form-label">${msg("manualKeyInstruction")}</label>
                            <div class="qr-manual-key">
                                <span id="totp-secret-key">${totp.totpSecretEncoded}</span>
                                <button type="button" id="copy-totp-key-btn" class="btn btn-outline" style="height: 2rem; padding: 0 0.5rem; font-size: 0.75rem; margin-left: auto;">
                                    ${msg("copySecretKey")}
                                </button>
                            </div>

                            <div class="form-group" style="margin-top: 1.25rem;">
                                <label for="totp" class="form-label">${msg("authenticatorCode")}</label>
                                <input type="text" id="totp" name="totp" class="form-input" autocomplete="off" autofocus placeholder="000000" />
                                <input type="hidden" id="totpSecret" name="totpSecret" value="${totp.totpSecret}" />
                            </div>

                            <div class="form-group">
                                <label for="userLabel" class="form-label">Device Name (Optional)</label>
                                <input type="text" id="userLabel" name="userLabel" class="form-input" placeholder="e.g. My iPhone" />
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary" name="submitAction" value="Save">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        <span>Verify & Enable</span>
                    </button>
                </div>
            </form>
        </div>
    </#if>

</@layout.mainLayout>
