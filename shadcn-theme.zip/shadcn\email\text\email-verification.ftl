${msg("emailVerificationSubject")}

${msg("emailVerificationBody")}

${link}

${msg("linkExpirationNotice", linkExpiration)}
