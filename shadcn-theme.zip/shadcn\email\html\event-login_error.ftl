<#import "template.ftl" as layout>
<@layout.emailLayout>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td style="padding-bottom: 16px;">
                <h1 style="margin: 0; font-size: 20px; font-weight: 600; color: #e11d48; letter-spacing: -0.025em;">
                    ${msg("eventLoginErrorSubject")}
                </h1>
            </td>
        </tr>
        <tr>
            <td style="padding-bottom: 24px; font-size: 14px; line-height: 1.6; color: #52525b;">
                <p style="margin: 0 0 12px 0;">${msg("eventLoginErrorBody", event.ipAddress, event.date?datetime)}</p>
                <div style="background-color: #fff1f2; border: 1px solid #fecdd3; border-radius: 6px; padding: 12px 16px; font-size: 13px; color: #9f1239;">
                    If this wasn't you, we strongly recommend that you change your password immediately and review your active sessions.
                </div>
            </td>
        </tr>
        <tr>
            <td style="padding-top: 16px; border-top: 1px solid #e4e4e7; font-size: 12px; line-height: 1.5; color: #71717a;">
                <p style="margin: 0;">Identity Security Alert &bull; ${properties.logoText!(realmName!'Keycloak')}</p>
            </td>
        </tr>
    </table>
</@layout.emailLayout>
