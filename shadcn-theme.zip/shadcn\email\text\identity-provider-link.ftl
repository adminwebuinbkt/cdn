${msg("identityProviderLinkSubject", identityProviderDisplayName)}

${msg("identityProviderLinkBody", identityProviderDisplayName, realmName, identityProviderContext.username)}

${link}

${msg("linkExpirationNotice", linkExpiration)}
