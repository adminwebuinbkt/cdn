<#import "template.ftl" as layout>
<@layout.registrationLayout displayInfo=true displayMessage=!messagesPerField.exists('username'); section>
    <#if section = "header">
        <h1 class="auth-title">${msg("resetPasswordTitle")}</h1>
        <p class="auth-subtitle">${msg("resetPasswordSubtitle")}</p>
    <#elseif section = "form">
        <form id="kc-reset-password-form" action="${url.loginAction}" method="post">
            <div class="form-group">
                <label for="username" class="form-label">
                    <#if !realm.loginWithEmailAllowed>
                        ${msg("username")}
                    <#elseif !realm.registrationEmailAsUsername>
                        ${msg("usernameOrEmail")}
                    <#else>
                        ${msg("email")}
                    </#if>
                </label>
                <input type="text" id="username" name="username" class="form-input <#if messagesPerField.existsError('username')>has-error</#if>" autofocus value="${(auth.attemptedUsername!'')}" placeholder="name@example.com" />
                <#if messagesPerField.existsError('username')>
                    <span class="field-error-message">
                        ${kcSanitize(messagesPerField.get('username'))?no_esc}
                    </span>
                </#if>
            </div>

            <div class="form-group" style="margin-top: 1.5rem;">
                <button class="btn btn-primary" type="submit">
                    <span>${msg("sendResetLink")}</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
                </button>
            </div>
        </form>
    <#elseif section = "info">
        <a href="${url.loginUrl}" class="btn btn-outline" style="width: 100%;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>
            <span>${msg("backToLogin")}</span>
        </a>
    </#if>
</@layout.registrationLayout>
