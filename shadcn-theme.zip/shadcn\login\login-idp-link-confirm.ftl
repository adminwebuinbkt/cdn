<#import "template.ftl" as layout>
<@layout.registrationLayout; section>
    <#if section = "header">
        <h1 class="auth-title">${msg("confirmLinkIdpTitle")}</h1>
        <p class="auth-subtitle">${msg("confirmLinkIdpReviewProfile")}</p>
    <#elseif section = "form">
        <form id="kc-register-form" action="${url.loginAction}" method="post">
            <div class="alert alert-info" style="margin-bottom: 1.5rem;">
                <svg class="alert-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
                <span>${msg("confirmLinkIdpInstruction", idpAlias!(brokerContext.idpConfig.alias!'social'))}</span>
            </div>

            <div class="form-group" style="display: flex; gap: 0.75rem; flex-direction: column;">
                <button type="submit" class="btn btn-primary" name="submitAction" id="updateProfile" value="updateProfile">${msg("confirmLinkIdpContinue")}</button>
                <button type="submit" class="btn btn-outline" name="submitAction" id="linkAccount" value="linkAccount">${msg("confirmLinkIdpReviewProfile")}</button>
            </div>
        </form>
    </#if>
</@layout.registrationLayout>
