<#import "template.ftl" as layout>
<@layout.registrationLayout; section>
    <#if section = "header">
        <div style="width: 48px; height: 48px; border-radius: 50%; background-color: hsl(var(--warning)/0.15); color: hsl(var(--warning)); display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        </div>
        <h1 class="auth-title">${msg("pageExpiredTitle")}</h1>
        <p class="auth-subtitle">${msg("pageExpiredSubtitle")}</p>
    <#elseif section = "form">
        <div class="form-group" style="margin-top: 1.5rem;">
            <a id="loginRestartLink" href="${url.loginRestartFlowUrl}" class="btn btn-primary" style="width: 100%;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
                <span>${msg("pageExpiredAction")}</span>
            </a>
        </div>
    </#if>
</@layout.registrationLayout>
