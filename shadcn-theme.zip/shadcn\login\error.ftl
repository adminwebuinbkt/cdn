<#import "template.ftl" as layout>
<@layout.registrationLayout displayMessage=false; section>
    <#if section = "header">
        <div style="width: 48px; height: 48px; border-radius: 50%; background-color: hsl(var(--destructive)/0.15); color: hsl(var(--destructive)); display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        </div>
        <h1 class="auth-title">${msg("errorTitle")}</h1>
        <p class="auth-subtitle">${msg("errorSubtitle")}</p>
    <#elseif section = "form">
        <div class="alert alert-error" style="margin: 1.5rem 0;">
            <svg class="alert-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
            <span>${message.summary}</span>
        </div>

        <#if client?? && client.baseUrl?has_content>
            <div class="form-group" style="margin-top: 1.5rem;">
                <a id="backToApplication" href="${client.baseUrl}" class="btn btn-outline" style="width: 100%;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>
                    <span>${kcSanitize(msg("backToApplication"))?no_esc}</span>
                </a>
            </div>
        </#if>
    </#if>
</@layout.registrationLayout>
